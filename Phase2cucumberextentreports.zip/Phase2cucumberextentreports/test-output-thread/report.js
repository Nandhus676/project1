$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"536092f6-6deb-40fb-97e1-940f5ea9015a","feature":"Register multiple users on the Rediff account Page","scenario":"Test rediff Register Account Page","start":1706594888496,"group":1,"content":"","tags":"","end":1706594907689,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});