package phase2demo;

import org.junit.jupiter.api.Test;
public class testdemo {


	// use Junit @Test annotation to exeucte your test methods
	
	@Test
	public void method1()
	{
		System.out.println("Junit Demo Test");
	}
}