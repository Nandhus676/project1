package phase2.phase2;

public class Calculator {

	public int add(int i, int j) {
		// TODO Auto-generated method stub
		return 0;
	}

}
