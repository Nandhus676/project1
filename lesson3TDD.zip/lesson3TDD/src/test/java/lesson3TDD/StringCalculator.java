package lesson3TDD;
public class StringCalculator {
	public int stringlength(String string) {
		
		int len = string.length();
		
		return len;
	}
	public String addstring(String s1, String s2) {
		
		String str = s1.concat(s2);//seleniumtool
		
		String str1 = str.toUpperCase();
		
		return str1;
	}
}

